package com.mansi.a29_sharedpreference;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    RatingBar rate;
    Button rateButton;

    SharedPreferences prefObj;
    String sharedpreferenceFile = "prefFile";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);



        setContentView(R.layout.activity_main);
        rate = findViewById(R.id.ratingBar);
        rateButton = findViewById(R.id.button);

        //get value of shared preference
//        save state of rating
        @SuppressLint("WrongConstant") SharedPreferences preferences = getSharedPreferences(sharedpreferenceFile,MODE_APPEND);
        float sharedRate = preferences.getFloat("rating", 0f);
        rate.setRating(sharedRate);

        rate.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                Toast.makeText(MainActivity.this, ""+rating, Toast.LENGTH_SHORT).show();
            }
        });

        rateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prefObj = getSharedPreferences(sharedpreferenceFile,MODE_PRIVATE);
                SharedPreferences.Editor editor = prefObj.edit();
                editor.putFloat("rating",rate.getRating());
                editor.commit();
            }
        });
    }
}