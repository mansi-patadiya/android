package com.mansi.context_onselectedcontext_menu;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView title;
    ImageView iv;
    AnimationDrawable ad;

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
//        this method is to set menu item on this menu
        getMenuInflater().inflate(R.menu.menu,menu);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        title = findViewById(R.id.title);
        iv = findViewById(R.id.img);
        registerForContextMenu(title);

//        1. create frame
        BitmapDrawable frame0 = (BitmapDrawable)getResources().getDrawable(R.drawable.zero);
        BitmapDrawable frame1 = (BitmapDrawable)getResources().getDrawable(R.drawable.one);
        BitmapDrawable frame2 = (BitmapDrawable)getResources().getDrawable(R.drawable.two);
        BitmapDrawable frame3 = (BitmapDrawable)getResources().getDrawable(R.drawable.three);
        BitmapDrawable frame4 = (BitmapDrawable)getResources().getDrawable(R.drawable.four);
        BitmapDrawable frame5 = (BitmapDrawable)getResources().getDrawable(R.drawable.five);
        BitmapDrawable frame6 = (BitmapDrawable)getResources().getDrawable(R.drawable.six);
        BitmapDrawable frame7 = (BitmapDrawable)getResources().getDrawable(R.drawable.seven);
        BitmapDrawable frame8 = (BitmapDrawable)getResources().getDrawable(R.drawable.eight);
        BitmapDrawable frame9 = (BitmapDrawable)getResources().getDrawable(R.drawable.nine);

//        add frame
        ad = new AnimationDrawable();
        ad.addFrame(frame0,50);
        ad.addFrame(frame1,50);
        ad.addFrame(frame2,50);
        ad.addFrame(frame3,50);
        ad.addFrame(frame4,50);
        ad.addFrame(frame5,50);
        ad.addFrame(frame6,50);
        ad.addFrame(frame7,50);
        ad.addFrame(frame8,50);
        ad.addFrame(frame9,50);

//        add this frames in imageview
        iv.setImageDrawable(ad);

    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId())
        {
            case R.id.start:
                ad.start();
                ad.setOneShot(false);
                break;
            case R.id.stop:
                ad.stop();
                break;
        }
        return super.onContextItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.start:
                ad.start();
                ad.setOneShot(false);
                break;
            case R.id.stop:
                ad.stop();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}