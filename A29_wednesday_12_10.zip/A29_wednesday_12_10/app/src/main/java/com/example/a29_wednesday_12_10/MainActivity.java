package com.example.a29_wednesday_12_10;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    SharedPreferences prefObj;
    String preferencefile = "PrefFile";
    RatingBar ratingValue;
    Button rateButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ratingValue = findViewById(R.id.ratingBar);
        rateButton = findViewById(R.id.button);

        ratingValue.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                Toast.makeText(MainActivity.this, String.valueOf(rating), Toast.LENGTH_SHORT).show();
                if(rating==0.5)
                {
                    Toast.makeText(MainActivity.this, "poor", Toast.LENGTH_SHORT).show();
                }
            }
        });

        rateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prefObj = getSharedPreferences(preferencefile,MODE_PRIVATE);
                SharedPreferences.Editor editor = prefObj.edit();
                editor.putFloat("rating",ratingValue.getRating());
                editor.commit();
            }
        });

    }
}
