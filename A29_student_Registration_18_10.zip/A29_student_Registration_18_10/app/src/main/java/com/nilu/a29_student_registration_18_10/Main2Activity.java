package com.nilu.a29_student_registration_18_10;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;

public class Main2Activity extends AppCompatActivity {

    ListView studentList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

//        String stuId = this.getIntent().getStringExtra("id");
//        String stuName = this.getIntent().getStringExtra("name");
//        String stuCourse = this.getIntent().getStringExtra("course");
//        String stuSemester = this.getIntent().getStringExtra("semester");

        studentList = findViewById(R.id.stuList);

    }
}

class CustomAdapter extends BaseAdapter
{
    Context context;

    @Override
    public int getCount() {
        return 0;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return null;
    }
}
