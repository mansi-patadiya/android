package com.nilu.a29_student_registration_18_10;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class Main2Activity extends AppCompatActivity {

    ListView studentList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        ArrayList<String> nameArray = this.getIntent().getStringArrayListExtra("name");
        ArrayList<String> courseArray = this.getIntent().getStringArrayListExtra("course");
        ArrayList<String> semArray = this.getIntent().getStringArrayListExtra("sem");

        studentList = findViewById(R.id.stuList);
        CustomAdapter customAdapter = new CustomAdapter(getApplicationContext(),nameArray,courseArray,semArray);
        studentList.setAdapter(customAdapter);

    }
}

class CustomAdapter extends BaseAdapter
{
    Context context;
    ArrayList<String> name,course,sem;
    LayoutInflater myInflate;

    public CustomAdapter(Context context, ArrayList<String> name, ArrayList<String> course, ArrayList<String> sem) {
        this.context = context;
        this.name = name;
        this.course = course;
        this.sem = sem;
        myInflate = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return name.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = myInflate.inflate(R.layout.custom_list_view,null);
        TextView nameText = convertView.findViewById(R.id.stuName);
        TextView courseText = convertView.findViewById(R.id.stuCourse);
        TextView semesterText = convertView.findViewById(R.id.stuSemester);
        nameText.setText(name.get(position));
        courseText.setText(course.get(position));
        semesterText.setText(sem.get(position));
        return convertView;
    }
}
