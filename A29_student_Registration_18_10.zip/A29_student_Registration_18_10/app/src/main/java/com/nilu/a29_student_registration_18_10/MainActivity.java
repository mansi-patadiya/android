package com.nilu.a29_student_registration_18_10;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText stuId,stuName,stuCourse,stuSem;
    Button addButton,showButton;
    ArrayList<String> nameArray = new ArrayList<>();
    ArrayList<String> courseArray = new ArrayList<>();
    ArrayList<String> semArray = new ArrayList<>();

    SQLiteDatabase myDatabase;
    static String CREATE_STUDENT_TABLE;
    final static String STUDENT_TABLE = "tableStudent";

    @SuppressLint("WrongConstant")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        stuName = findViewById(R.id.stuName);
        stuCourse = findViewById(R.id.stuCourse);
        stuSem = findViewById(R.id.studentSem);

        addButton = findViewById(R.id.add);
        showButton = findViewById(R.id.show);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent intent = new Intent(MainActivity.this,Main2Activity.class);
//                intent.putExtra("id",stuId.toString());
//                intent.putExtra("name",stuName.toString());
//                intent.putExtra("course",stuCourse.toString());
//                intent.putExtra("semester",stuSem.toString());
//                startActivity(intent);
                String name = stuName.getText().toString();
                String course = stuCourse.getText().toString();
                String sem = stuSem.getText().toString();

                //insert data
                ContentValues values = new ContentValues();
                values.put("name",name);
                values.put("course",course);
                values.put("semester",sem);
                myDatabase.insert(STUDENT_TABLE,null,values);
                Toast.makeText(MainActivity.this, "Data Added Succesfully", Toast.LENGTH_SHORT).show();
            }
        });

        showButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,Main2Activity.class);
                startActivity(intent);
            }
        });

        //create database
        myDatabase = openOrCreateDatabase("Student.db",SQLiteDatabase.CREATE_IF_NECESSARY,null);

        //create table
        try
        {
            CREATE_STUDENT_TABLE = "CREATE TABLE IF NOT EXISTS tableStudent("+"id INTEGER PRIMARY KEY AUTOINCREMENT,"+"name TEXT,"+"course TEXT,"+"semester TEXT"+")";
            myDatabase.execSQL(CREATE_STUDENT_TABLE);
        }
        catch (Exception e)
        {
            Toast.makeText(this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}
