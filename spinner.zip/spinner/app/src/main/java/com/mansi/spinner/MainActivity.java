package com.mansi.spinner;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {

    ImageView iv;
    Spinner sp;
    Animation ani;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        iv = findViewById(R.id.img);
        sp = findViewById(R.id.spinner);
//        create an array to add into spinner
        String animation_data[] = {"alpha","rotate","scale","translate"};
//        it will set value on spinner
        sp.setAdapter(new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_spinner_item,animation_data));
       sp.setOnItemSelectedListener(
               new AdapterView.OnItemSelectedListener() {
                   @Override
                   public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                       switch (position){
                           case 0:
                              ani = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.alpha);
                              iv.startAnimation(ani);
                              break;
                           case 1:
                               ani = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.rotate);
                               iv.startAnimation(ani);
                               break;
                           case 2:
                               ani = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.scale);
                               iv.startAnimation(ani);
                               break;
                           case 3:
                               ani = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.translate);
                               iv.startAnimation(ani);
                               break;
                       }
                   }

                   @Override
                   public void onNothingSelected(AdapterView<?> parent) {

                   }
               }
       );


    }
}