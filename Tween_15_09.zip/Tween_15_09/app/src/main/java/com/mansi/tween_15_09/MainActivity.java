package com.mansi.tween_15_09;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Spinner sp;
    Animation animation;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sp = findViewById(R.id.spinner);

        String []tweenArray = getResources().getStringArray(R.array.strAnimation);
        ArrayAdapter ap = new ArrayAdapter(getApplicationContext(),android.R.layout.simple_spinner_item,tweenArray);
        sp.setAdapter(ap);

        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                Toast.makeText(MainActivity.this, ""+sp.getSelectedItem(), Toast.LENGTH_SHORT).show();
                ImageView image = findViewById(R.id.imageView);
                String selectedItem = sp.getSelectedItem().toString();
                 switch (selectedItem)
                 {
                     case "Alpha":
                         animation = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.alpha);
                         image.startAnimation(animation);
                         break;
                     case "Rotate":
                         animation = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.rotate);
                         image.startAnimation(animation);
                         break;
                     case "Scale":
                         animation = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.scale);
                         image.startAnimation(animation);
                         break;
                     case "Translate":
                         animation = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.translate);
                         image.startAnimation(animation);
                         break;
                 }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
}