package com.mansi.framebyframeanimation;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    ImageView iv;
    Button startButton,stopButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        iv = findViewById(R.id.imageView);
        startButton = findViewById(R.id.start);
        stopButton = findViewById(R.id.stop);

//        first create frame
        BitmapDrawable frame0 = (BitmapDrawable)getResources().getDrawable(R.drawable.zero);
        BitmapDrawable frame1 = (BitmapDrawable)getResources().getDrawable(R.drawable.one);
        BitmapDrawable frame2 = (BitmapDrawable)getResources().getDrawable(R.drawable.two);
        BitmapDrawable frame3 = (BitmapDrawable)getResources().getDrawable(R.drawable.three);
        BitmapDrawable frame4 = (BitmapDrawable)getResources().getDrawable(R.drawable.four);
        BitmapDrawable frame5 = (BitmapDrawable)getResources().getDrawable(R.drawable.five);
        BitmapDrawable frame6 = (BitmapDrawable)getResources().getDrawable(R.drawable.six);
        BitmapDrawable frame7 = (BitmapDrawable)getResources().getDrawable(R.drawable.seven);
        BitmapDrawable frame8 = (BitmapDrawable)getResources().getDrawable(R.drawable.eight);
        BitmapDrawable frame9 = (BitmapDrawable)getResources().getDrawable(R.drawable.nine);

//        to start animation add all this frame in animationdrawable
        AnimationDrawable ad = new AnimationDrawable();
        ad.addFrame(frame0,50);
        ad.addFrame(frame1,50);
        ad.addFrame(frame2,50);
        ad.addFrame(frame3,50);
        ad.addFrame(frame4,50);
        ad.addFrame(frame5,50);
        ad.addFrame(frame6,50);
        ad.addFrame(frame7,50);
        ad.addFrame(frame8,50);
        ad.addFrame(frame9,50);

//        add this animation in imageview
        iv.setImageDrawable(ad);

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ad.start();
                ad.setOneShot(false);
            }
        });

        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ad.stop();
            }
        });
    }
}
