package com.mansi.listview;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {

    ListView lst;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

//        TextView txt = findViewById(R.id.textView);

        lst = findViewById(R.id.lstview);
        ArrayList<String> nameArr = this.getIntent().getStringArrayListExtra("name");
        ArrayList<String> desgArr = this.getIntent().getStringArrayListExtra("desg");

        System.out.println(nameArr.size()+" "+desgArr.size());
//        txt.setText(String.valueOf(nameArr.size()));

        CustomAdapter customObj = new CustomAdapter(getApplicationContext(),nameArr,desgArr);
        lst.setAdapter(customObj);

    }
}

class CustomAdapter extends BaseAdapter
{
    Context context;
    ArrayList<String> nameArray,desgArray;
    LayoutInflater myInflate;

    public CustomAdapter(Context context, ArrayList<String> nameArray, ArrayList<String> desgArray) {
        this.context = context;
        this.nameArray = nameArray;
        this.desgArray = desgArray;
        myInflate = (LayoutInflater.from(context));
    }

    @Override
    public int getCount() {
        return nameArray.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = myInflate.inflate(R.layout.showonlistview,null);
        TextView tv1 = view.findViewById(R.id.name);
        TextView tv2 = view.findViewById(R.id.desg);
        tv1.setText(nameArray.get(i).toString());
        tv2.setText(desgArray.get(i).toString());
        return view;
    }
}

//class CustomAdapter extends BaseAdapter
//{
//    Context context;
//    ArrayList<String> NA;
//    ArrayList<String> DA;
//    LayoutInflater myinflate;
//
//
//    public CustomAdapter(Context context, ArrayList<String> NA, ArrayList<String> DA)
//    {
//        this.context = context;
//        this.NA = NA;
//        this.DA = DA;
//        myinflate = (LayoutInflater.from(context));
//    }
//
//    @Override
//    public int getCount() {
//        return DA.size();
//    }
//
//    @Override
//    public Object getItem(int i) {
//        return null;
//    }
//
//    @Override
//    public long getItemId(int i) {
//        return 0;
//    }
//
//    @Override
//    public View getView(int i, View view, ViewGroup viewGroup) {
//        view = myinflate.inflate(R.layout.showonlistview,null);
//        TextView tv1 = view.findViewById(R.id.name);
//        TextView tv2 = view.findViewById(R.id.desg);
//        tv1.setText(NA.get(i).toString());
//        tv2.setText(DA.get(i).toString());
//        return view;
//    }
//}