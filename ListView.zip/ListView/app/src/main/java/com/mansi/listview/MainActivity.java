package com.mansi.listview;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText name,designation;
    Button addButton;
    ArrayList<String> nameArray = new ArrayList<>();
    ArrayList<String> desgArray = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name = findViewById(R.id.name);
        designation = findViewById(R.id.desg);
        addButton = findViewById(R.id.add);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,MainActivity2.class);
                nameArray.add(name.getText().toString());
                desgArray.add(designation.getText().toString());
                intent.putStringArrayListExtra("name",nameArray);
                intent.putStringArrayListExtra("desg",desgArray);
                startActivity(intent);
            }
        });
    }
}